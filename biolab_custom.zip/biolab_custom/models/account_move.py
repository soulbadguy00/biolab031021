# -*- coding:utf-8 -*-


from odoo import api, models, fields, _
from num2words import num2words


class AccountMove(models.Model):
    _inherit = "account.move"

    

    def _getAmountToText(self):
        for move in self:
            amount_text = num2words(move.netpaie, lang='fr')
            move.amount_text = amount_text


    acompte = fields.Boolean("Avance")
    num_bdl = fields.Many2one('stock.picking',"Bon de Livraison", required=False)
    amount_text = fields.Char("Montant en lettres", compute="_getAmountToText")
    partner_contact_id = fields.Many2one('res.partner', "Contact", domain="[('type', '=', 'ocntact')]")
    object = fields.Char("Object", required=False, readonly=False)
    avance = fields.Monetary(string='Avance', store=True, readonly=False, size=10)
    netpaie = fields.Monetary(string='Net a payer', store=True, readonly=True, compute='_compute_balances')




    @api.depends('amount_total', 'avance')
    def _compute_balances(self):
        for line in self:
            line.netpaie = line.amount_total - line.avance

